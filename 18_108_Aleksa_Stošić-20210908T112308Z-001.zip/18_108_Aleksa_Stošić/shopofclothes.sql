-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2021 at 12:22 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopofclothes`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'logging in', NULL, NULL),
(2, 'ordering', NULL, NULL),
(3, 'logging out', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `activity_users`
--

CREATE TABLE `activity_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `activity_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_users`
--

INSERT INTO `activity_users` (`id`, `activity_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2021-03-18 12:33:29', '2021-03-18 12:33:29'),
(2, 3, 1, '2021-03-18 12:34:17', '2021-03-18 12:34:17'),
(3, 1, 2, '2021-03-18 14:45:58', '2021-03-18 14:45:58'),
(4, 3, 2, '2021-03-18 14:47:14', '2021-03-18 14:47:14'),
(5, 1, 2, '2021-03-18 15:16:55', '2021-03-18 15:16:55'),
(6, 2, 2, '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(7, 2, 2, '2021-03-18 15:28:14', '2021-03-18 15:28:14'),
(8, 3, 2, '2021-03-18 15:29:39', '2021-03-18 15:29:39'),
(9, 1, 1, '2021-03-18 15:37:01', '2021-03-18 15:37:01'),
(10, 2, 1, '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(11, 3, 1, '2021-03-18 15:40:11', '2021-03-18 15:40:11'),
(12, 1, 2, '2021-03-18 15:44:29', '2021-03-18 15:44:29'),
(13, 3, 2, '2021-03-18 15:44:38', '2021-03-18 15:44:38'),
(14, 1, 2, '2021-03-18 16:03:39', '2021-03-18 16:03:39'),
(15, 3, 2, '2021-03-18 16:09:33', '2021-03-18 16:09:33'),
(16, 1, 1, '2021-03-18 21:29:02', '2021-03-18 21:29:02'),
(17, 3, 1, '2021-03-18 21:31:00', '2021-03-18 21:31:00'),
(18, 1, 1, '2021-03-18 21:36:25', '2021-03-18 21:36:25'),
(19, 3, 1, '2021-03-18 21:44:39', '2021-03-18 21:44:39');

-- --------------------------------------------------------

--
-- Table structure for table `admin_menus`
--

CREATE TABLE `admin_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_menus`
--

INSERT INTO `admin_menus` (`id`, `name`, `route`, `order`, `created_at`, `updated_at`) VALUES
(1, 'Products', 'adminPanel.index', 1, NULL, NULL),
(2, 'Orders', 'ordersAdmin', 2, NULL, NULL),
(3, 'Contact messages', 'message.index', 3, NULL, NULL),
(4, 'Users', 'viewUsers.index', 4, NULL, NULL),
(5, 'Activity', 'activities', 5, NULL, NULL),
(6, 'Product popularity', 'PopularityProducts', 6, NULL, NULL),
(7, 'Logout', 'logout', 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Martini Vesto', '2021-03-18 12:36:04', '2021-03-18 12:36:04'),
(2, 'dolce & gabana', '2021-03-18 12:36:12', '2021-03-18 12:36:12'),
(3, 'guchie', '2021-03-18 12:36:21', '2021-03-18 12:36:21'),
(4, 'saila', '2021-03-18 12:36:50', '2021-03-18 12:36:50');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 't-shirts', '2021-03-18 12:35:48', '2021-03-18 12:35:48'),
(2, 'jeans', '2021-03-18 13:01:47', '2021-03-18 13:01:47'),
(3, 'jackets', '2021-03-18 13:16:56', '2021-03-18 13:16:56'),
(4, 'decks', '2021-03-18 13:35:04', '2021-03-18 13:35:04'),
(6, 'dresses', '2021-03-18 13:46:17', '2021-03-18 13:46:17');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateTime` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'Greska', 'fdlkaHFIOoafjaM M fmkl;AK FK fnSFNj nasdj Nj njfnaJNFsfAFsfJFAkfjsafjaKFJAskfjaKFJAkfja', '2021-03-18 15:31:11', '2021-03-18 15:31:11'),
(2, 'AlSSD DSA', 'DDSADSA@gmail.com', 'DSAASfA NJSADGN JASDFN Js', 'GSDFASDGSDAGSSDAFSAj kJ FJhf AJ F nj afsNAn jfn jaFN JAS NJSAFNFFN', '2021-03-18 15:31:45', '2021-03-18 15:31:45'),
(3, 'goran stajic', 'goranstajic05@ict.edu.rs', 'sdasdg', 'asdasdasdasdasdasdasdyers', '2021-03-18 16:09:27', '2021-03-18 16:09:27'),
(10, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'DA li ovo radi', 'ako radi supperrr , ako ne begaj', '2021-03-18 19:08:33', '2021-03-18 19:08:33'),
(11, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'DA li ovo radi', 'ako radi supperrr , ako ne begaj', '2021-03-18 19:10:49', '2021-03-18 19:10:49'),
(12, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'Greska braleee', 'dsadasdasdasdasdasdasdasd', '2021-03-18 19:14:03', '2021-03-18 19:14:03'),
(14, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'DA li ovo radi', 'eqfdsafasdsfadsfafsd', '2021-03-18 19:19:35', '2021-03-18 19:19:35'),
(15, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'Greska braleee', 'fdsafdsafdsafasddsafdsafdsafdsafdsa', '2021-03-18 19:27:56', '2021-03-18 19:27:56'),
(16, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'DA li ovo radi', 'wjicfasJFfskKSAofKFASoFKOFKSOFAofsaOFKA', '2021-03-18 19:30:24', '2021-03-18 19:30:24'),
(18, 'Aleksa Stosic', 'aki.sto99@gmail.com', 'radiiiii', 'manijace dassdaasdas', '2021-03-18 19:32:34', '2021-03-18 19:32:34');

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`id`, `discount`, `created_at`, `updated_at`) VALUES
(1, '0.00', NULL, NULL),
(2, '0.10', NULL, NULL),
(3, '0.20', NULL, NULL),
(4, '0.30', NULL, NULL),
(5, '0.40', NULL, NULL),
(6, '0.50', NULL, NULL),
(7, '0.60', NULL, NULL),
(8, '0.70', NULL, NULL),
(9, '0.80', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `path`, `created_at`, `updated_at`) VALUES
(1, 'drw8L8V4bkUXksP0HKOnLlMd4AU4JpcBzdDDAcBl.jpg', '2021-03-18 12:43:37', '2021-03-18 12:43:37'),
(2, '82Z7ovayVkJIxfgIDG1F84zIKo41i8Du69TQfaiO.jpg', '2021-03-18 12:49:16', '2021-03-18 12:49:16'),
(3, 'kmDEsTXM3ZosrekO20JsaKUY6lMKp3ofxSzZmHv3.jpg', '2021-03-18 12:51:36', '2021-03-18 12:51:36'),
(4, 'dYM4EN6YxWVO37pW7T2oiBRIldgcs1JJLqfOHglw.jpg', '2021-03-18 12:53:34', '2021-03-18 12:53:34'),
(5, 'gqjeOpWC1qnAjMOor4ga2SfOKDXSQmvaR9xfyL4g.jpg', '2021-03-18 12:56:38', '2021-03-18 12:56:38'),
(6, 'pXUSmaGI7MUwoIBp4k4JfUL4UDi2PY9ZSLW0t31G.jpg', '2021-03-18 12:58:40', '2021-03-18 12:58:40'),
(7, 'LvD5W7GZoqxHrg6VIUNStdtL6vlLFMvD87UxQd9Y.jpg', '2021-03-18 12:59:33', '2021-03-18 12:59:33'),
(8, 'ohAxVqbwArGEYUTtRwnAxvbEoNzI8kbrb84PDdUv.jpg', '2021-03-18 13:05:43', '2021-03-18 13:05:43'),
(9, 'R94BT0i5S9HDi9lOh9fMiGhxrj7Gk67jDZt0g6lE.jpg', '2021-03-18 13:07:30', '2021-03-18 13:07:30'),
(10, '34kNBK4M2ZYpRpFKN6T2S1Jn5z5Sj1GOPQxZKfPe.jpg', '2021-03-18 13:09:34', '2021-03-18 13:09:34'),
(11, 'Lgtb0U0uCQXF0hkfflfvpNyKyJ8YHVQcbgQqFbeC.jpg', '2021-03-18 13:12:42', '2021-03-18 13:12:42'),
(12, 'mS0ErTlTASzgsFAOUVgPUzk4SqCzfMMERTV54GSh.jpg', '2021-03-18 13:14:27', '2021-03-18 13:14:27'),
(13, 'SjDRelZrE7nyulcQF4XWQQScOOEonK2nk0IeewXx.jpg', '2021-03-18 13:16:25', '2021-03-18 13:16:25'),
(14, 'bpkxfKqAbNVIRgNvnQiCIlb8HYG5a4JnDkZMxYin.jpg', '2021-03-18 13:24:52', '2021-03-18 13:24:52'),
(15, '2BWrK3ttzSO5ILzbNezOSfAWfNf3Q0B0qBYSBtkb.jpg', '2021-03-18 13:27:05', '2021-03-18 13:27:05'),
(16, 'w6zaDn6xop6VyGvJ1ov6arwbAmANnnhnQfolbsgv.png', '2021-03-18 13:29:01', '2021-03-18 13:29:01'),
(17, 'bWlas4cMG6OinPmCbJnpV4cvPSIDBGQuV14WaE0S.jpg', '2021-03-18 13:30:53', '2021-03-18 13:30:53'),
(18, 'Y3UQJPF61JRuUXziCrgF17Cw38q1ZewNWAIboep3.png', '2021-03-18 13:32:17', '2021-03-18 13:32:17'),
(19, 'kBbJQu9VSgWVB5wzYmpX7Oinfwjw75PuwGzAXlYX.jpg', '2021-03-18 13:34:32', '2021-03-18 13:34:32'),
(20, '8rOyX347FOyZKoTEY1IgsKJ0SRGFP1HwJ8ug9QVJ.jpg', '2021-03-18 13:38:19', '2021-03-18 13:38:19'),
(21, 'wDQv3dBUpqmQPTVjjDTLg4RK8Hl5tvMydfATzISd.jpg', '2021-03-18 13:40:49', '2021-03-18 13:40:49'),
(22, 'F5k3qVgDGNrlnaiBUV5sn7jnWwlwDNf5nwa0FHu8.jpg', '2021-03-18 13:48:41', '2021-03-18 13:48:41'),
(23, 'tG7hWnxgJp5YlX2k1lbTyWpTUQoOSYDvAORgXdfJ.jpg', '2021-03-18 13:50:35', '2021-03-18 13:50:35'),
(24, 'ZhtiL4H23wBzQQUZmkuKpZDHHoBZd5COy70tquUT.jpg', '2021-03-18 13:51:47', '2021-03-18 13:51:47'),
(25, 'zwW7OdaMyIEsOq4bkYKi5OBXD92wryloTSxUA4RS.jpg', '2021-03-18 14:27:59', '2021-03-18 14:27:59'),
(26, 'LhoRTcYvp2vVD6tEgbZag0iZmgxlnvHqvOvw5UJL.jpg', '2021-03-18 14:29:52', '2021-03-18 14:29:52'),
(27, '6i5nKtBXwqB939JInUlVnIFrWDOI2kWqltuRmBx5.jpg', '2021-03-18 14:30:40', '2021-03-18 14:30:40'),
(28, 'a9E7ChvVpisw3Gj0WXsvykdOblIt3AwnpGF4vQeS.jpg', '2021-03-18 14:35:11', '2021-03-18 14:35:11');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `route`, `parent`, `order`, `created_at`, `updated_at`) VALUES
(1, 'Login', 'login', NULL, 3, NULL, NULL),
(2, 'Register', 'register', NULL, 3, NULL, NULL),
(3, 'Home', 'home', NULL, 1, NULL, NULL),
(4, 'Account', 'account', NULL, 4, NULL, NULL),
(5, 'Contact', 'contact', NULL, 5, NULL, NULL),
(6, 'Shop', NULL, NULL, 2, NULL, NULL),
(7, 'Shop products', 'shop', 6, NULL, NULL, NULL),
(8, 'Cart', 'cart', 6, NULL, NULL, NULL),
(9, 'Sign out', 'logout', NULL, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1133, '2021_03_09_190355_admin_menu', 1),
(1641, '2021_03_01_125416_create_products_table', 2),
(1642, '2021_03_01_131617_create_categories_table', 2),
(1643, '2021_03_01_132305_create_types_table', 2),
(1644, '2021_03_01_132537_create_brands_table', 2),
(1645, '2021_03_01_133227_create_sizes_table', 2),
(1646, '2021_03_01_133743_create_images_table', 2),
(1647, '2021_03_01_134317_create_prices_table', 2),
(1648, '2021_03_01_135958_create_product_images_table', 2),
(1649, '2021_03_01_140110_create_product_prices_table', 2),
(1650, '2021_03_01_140225_create_product_sizes_table', 2),
(1651, '2021_03_01_140332_create_discounts_table', 2),
(1652, '2021_03_01_191708_create_users_table', 2),
(1653, '2021_03_01_192216_create_roles_table', 2),
(1654, '2021_03_01_192340_create_comments_table', 2),
(1655, '2021_03_01_192805_create_product_comments_table', 2),
(1656, '2021_03_01_193100_create_user_product_comments_table', 2),
(1657, '2021_03_01_193442_create_orders_table', 2),
(1658, '2021_03_01_193929_create_order_details_table', 2),
(1659, '2021_03_02_154115_create_menus_table', 2),
(1660, '2021_03_10_002151_create_admin_menus_table', 2),
(1661, '2021_03_11_104623_create_contacts_table', 2),
(1662, '2021_03_15_152801_create_activities_table', 2),
(1663, '2021_03_15_154756_create_activity_users_table', 2),
(1664, '2021_03_15_204548_create_popularity_products_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 2, '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(2, 2, '2021-03-18 15:28:14', '2021-03-18 15:28:14'),
(3, 1, '2021-03-18 15:39:42', '2021-03-18 15:39:42');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `size` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `size`, `quantity`, `amount`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 1, '80.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(2, 1, 1, 4, 1, '80.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(3, 1, 2, 1, 5, '170.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(4, 1, 2, 2, 8, '272.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(5, 1, 4, 1, 2, '28.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(6, 1, 4, 4, 3, '28.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(7, 1, 8, 1, 1, '49.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(8, 1, 8, 5, 15, '735.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(9, 1, 23, 4, 1, '225.00', '2021-03-18 15:17:10', '2021-03-18 15:17:10'),
(10, 2, 20, 1, 1, '18.90', '2021-03-18 15:28:14', '2021-03-18 15:28:14'),
(11, 2, 20, 3, 2, '37.80', '2021-03-18 15:28:14', '2021-03-18 15:28:14'),
(12, 2, 12, 4, 2, '63.00', '2021-03-18 15:28:14', '2021-03-18 15:28:14'),
(13, 2, 19, 4, 3, '450.00', '2021-03-18 15:28:14', '2021-03-18 15:28:14'),
(14, 3, 2, 2, 2, '68.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(15, 3, 2, 6, 1, '34.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(16, 3, 5, 6, 4, '144.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(17, 3, 14, 1, 1, '105.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(18, 3, 16, 1, 3, '300.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(19, 3, 12, 5, 2, '63.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42'),
(20, 3, 7, 4, 1, '30.00', '2021-03-18 15:39:42', '2021-03-18 15:39:42');

-- --------------------------------------------------------

--
-- Table structure for table `popularity_products`
--

CREATE TABLE `popularity_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `numberOfClicks` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `popularity_products`
--

INSERT INTO `popularity_products` (`id`, `product_id`, `numberOfClicks`, `created_at`, `updated_at`) VALUES
(1, 1, 3, '2021-03-18 14:46:31', '2021-03-18 21:26:11'),
(2, 2, 4, '2021-03-18 15:11:11', '2021-03-18 15:37:53'),
(3, 4, 5, '2021-03-18 15:11:28', '2021-03-18 15:11:42'),
(4, 8, 2, '2021-03-18 15:12:00', '2021-03-18 15:12:10'),
(5, 23, 1, '2021-03-18 15:12:32', '2021-03-18 15:12:32'),
(6, 20, 3, '2021-03-18 15:19:22', '2021-03-18 15:19:37'),
(7, 12, 2, '2021-03-18 15:26:50', '2021-03-18 15:38:35'),
(8, 19, 1, '2021-03-18 15:27:12', '2021-03-18 15:27:12'),
(9, 5, 3, '2021-03-18 15:37:57', '2021-03-18 21:26:23'),
(10, 14, 1, '2021-03-18 15:38:22', '2021-03-18 15:38:22'),
(11, 16, 1, '2021-03-18 15:38:30', '2021-03-18 15:38:30'),
(12, 7, 2, '2021-03-18 15:38:42', '2021-03-18 21:27:11');

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `id` int(10) UNSIGNED NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`id`, `price`, `created_at`, `updated_at`) VALUES
(1, '100.00', '2021-03-18 12:43:37', '2021-03-18 12:43:37'),
(2, '34.00', '2021-03-18 12:49:16', '2021-03-18 12:49:16'),
(3, '50.00', '2021-03-18 12:51:36', '2021-03-18 12:51:36'),
(4, '40.00', '2021-03-18 12:53:34', '2021-03-18 12:53:34'),
(5, '60.00', '2021-03-18 12:56:38', '2021-03-18 12:56:38'),
(6, '70.00', '2021-03-18 13:05:43', '2021-03-18 13:05:43'),
(7, '85.00', '2021-03-18 13:07:30', '2021-03-18 13:07:30'),
(8, '121.00', '2021-03-18 13:09:34', '2021-03-18 13:09:34'),
(9, '75.00', '2021-03-18 13:12:42', '2021-03-18 13:12:42'),
(10, '45.00', '2021-03-18 13:14:27', '2021-03-18 13:14:27'),
(11, '29.00', '2021-03-18 13:16:25', '2021-03-18 13:16:25'),
(12, '150.00', '2021-03-18 13:24:52', '2021-03-18 13:24:52'),
(13, '140.00', '2021-03-18 13:27:05', '2021-03-18 13:27:05'),
(14, '200.00', '2021-03-18 13:29:01', '2021-03-18 13:29:01'),
(15, '180.00', '2021-03-18 13:30:53', '2021-03-18 13:30:53'),
(16, '256.00', '2021-03-18 13:32:17', '2021-03-18 13:32:17'),
(17, '300.00', '2021-03-18 13:34:32', '2021-03-18 13:34:32'),
(18, '21.00', '2021-03-18 13:38:19', '2021-03-18 13:38:19'),
(19, '130.00', '2021-03-18 13:40:49', '2021-03-18 13:40:49'),
(20, '302.00', '2021-03-18 13:48:41', '2021-03-18 13:48:41'),
(21, '250.00', '2021-03-18 13:50:35', '2021-03-18 13:50:35');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category_id`, `type_id`, `brand_id`, `created_at`, `updated_at`) VALUES
(1, 't-shirt casual', 'Cotton jersey T-shirt with 3D DG logo and print:\r\n• Regular fit\r\n• Round neck\r\n• Short sleeves\r\n• The piece measures 71 cm - 28 inches from the rear collar seam on a size IT 48\r\n• The model is 185 cm - 72.8 inches tall and wears a size IT 48\r\n• Made in Italy', 1, 1, 1, '2021-03-18 12:43:37', '2021-03-18 12:43:37'),
(2, 'Shmecki', '92% Polyester, 8% Spandex.\r\n\r\nMachine wash cold with like colors inside out. Do not bleach. Do not tumble dry. Flat dry for best results. Warm iron if needed.\r\n\r\nMade in USA', 1, 3, 4, '2021-03-18 12:49:16', '2021-03-18 12:49:16'),
(3, 'tugylugi', 'Back from our archives. Reissued and made even cooler.\r\n\r\nSoft jersey knit.\r\n\r\nShort sleeves.\r\n\r\nCrewneck.\r\n\r\nPatch pocket at chest.\r\n\r\nGarment-dyed and washed with a special technique for incredible softness and true color.', 1, 3, 3, '2021-03-18 12:51:36', '2021-03-18 12:51:36'),
(4, 'Grtzove', 'The everyday essential, made from 100% cotton for a cool and comfortable fit and styled with a classic crew neck.\r\n90% Cotton, 10% Viscose.', 1, 2, 1, '2021-03-18 12:53:34', '2021-03-18 12:53:34'),
(5, 't-shirts Layerovski', 'Somewhere deep down, every golfer is a bit of a purist. What better way to celebrate than with Linksoul’s sweet ‘purist’ design? This tee is perfect for wear when the weather’s warm or as a layer when the temperature dips.', 1, 2, 2, '2021-03-18 12:56:38', '2021-03-18 12:56:38'),
(7, 't-shirts Sqiptaria', 'Add some colour to your casual wear this season with one of our soft cotton tees. With a classic crew neck and short sleeves, team it with a pair of our denim jeans for a downtime casual look. \r\nPetrol blue t-shirt\r\nCrew neck \r\nShort sleeves\r\nModel\'s chest is 38\"\r\nModel wears a size M\r\nModel\'s height is 6\'2\"', 1, 2, 2, '2021-03-18 12:59:33', '2021-03-18 12:59:33'),
(8, 'Ladies jeans', 'ORGANIC COTTON is derived from genetically unmodified seeds, with respect to the environment and in line with the natural cycle of life. The fabric is delicate for the skin, breathable, antibacterial and biodegradable.', 2, 2, 1, '2021-03-18 13:05:43', '2021-03-18 13:05:43'),
(9, 'Cobyes jeans', 'These Tommy Jeans slim jeans will go great with your favourite outfits. The fitted cut will nicely show off your silhouette. This pair wins the award for wardrobe staple.', 2, 3, 2, '2021-03-18 13:07:30', '2021-03-18 13:07:30'),
(10, 'Banais  jeans', 'These Tommy Jeans slim jeans will go great with your favourite outfits. The fitted cut will nicely show off your silhouette. This pair wins the award for wardrobe staple.', 2, 1, 3, '2021-03-18 13:09:34', '2021-03-18 13:09:34'),
(11, 'maackias  jeans', 'A pair of extra high straight leg jeans that are made from a 95% organic cotton and 5% recycled cotton blend. They sit high at the waist and have a classic five pocket style.', 2, 1, 3, '2021-03-18 13:12:42', '2021-03-18 13:12:42'),
(12, 'rebiais  jeans', 'A pair of extra high straight leg jeans that are made from a 95% organic cotton and 5% recycled cotton blend. They sit high at the waist and have a classic five pocket style.', 2, 2, 4, '2021-03-18 13:14:27', '2021-03-18 13:14:27'),
(13, 'moyals jeans', 'We love to see how you style your favourites from H&M and H&M HOME: Keep sharing your personal style with @HM and #HMxME for a chance to be featured at hm.com, in our marketing materials and in our stores.', 2, 3, 4, '2021-03-18 13:16:25', '2021-03-18 13:16:25'),
(14, 'Men\'s Bomber Jacket Casual Lightweight Varsity', 'MATERIAL-- Polyester and Spandex; Lightweight and Elastic, Windbreaker, comfortable and durable.\r\nFEATURES-- Full zip-front closure,Long sleeve,rib(collar,cuff and hem),functional pocket.Classic and stylish.\r\nCLOTHING MATCH-- Perfect mix and match with t-shirts, shirts, sweater, denim pants, casual pants and etc. Make your bomber jacket a statement piece by pairing it with basic garments in neutral colours.', 3, 1, 1, '2021-03-18 13:24:52', '2021-03-18 13:24:52'),
(15, 'Puffer Jackets Parka Coats Winter Outwear', '100% polyester\r\nZipper closure\r\nFabric: 100% Polyester. Lining: Sherpa Fleece.Thickened inner fleece lining, bringing warmth to you all the time.\r\nFeatures:Detachable hooded,Color block,Zipper +Button closure,Ribbed cuffs,Side pockets with snap,Practical inner pocket,Heightening front windproof collar,Slim fit,Short length', 3, 1, 2, '2021-03-18 13:27:05', '2021-03-18 13:27:05'),
(16, 'marela penera', '• Matte ripstop polyester\r\n• DownPlus+ insulation - proprietary blend of 750 fill power 65% responsibly sourced waterproof goose down and 35% ultra-fine PrimaLoft™ synthetic fibers\r\n• 80g insulation everywhere except back panel\r\n• 90g insulation in back panel', 3, 3, 3, '2021-03-18 13:29:01', '2021-03-18 13:29:01'),
(17, 'Women\'s Winter Warmer Jacket', 'This casual outerwear delivers warmth, protection and style at a remarkably affordable price. The highly water-resistant nylon shell withstands wet and windy days, ensuring comfort in colder weather. It also exceeds our rigorous abrasion and strength tests, so you can count on it to hold up to everyday wear.', 3, 2, 4, '2021-03-18 13:30:53', '2021-03-18 13:30:53'),
(18, 'L\'ACADEMIE', 'A dramatic jacket with a lengthier silhouette in a neutral hue will make any \'fit look so polished.', 3, 2, 1, '2021-03-18 13:32:17', '2021-03-18 13:32:17'),
(19, 'Curvasia la majes', 'shoulder epaulettes\r\nlong sleeves with belted cuffs\r\ndouble-breasted button fastening\r\nwaist belt with buckle\r\ntwo side pockets', 3, 2, 2, '2021-03-18 13:34:32', '2021-03-18 13:34:32'),
(20, 'Some deksi', 'Condition:	New without tags: A brand-new, unused, and unworn item (including handmade items) that is not in original packaging or may be missing original packaging materials (such as the original box or bag). The original tags may not be attached. See all condition definitions', 4, 1, 4, '2021-03-18 13:38:19', '2021-03-18 13:38:19'),
(21, 'TIMBER! PICK YOUR POISON - HOODIE FOR WOMEN', 'Fabric: French terry sweat fabric\r\n\r\nFit:\r\nCasual and unrestricted relaxed fit\r\nLining:\r\nUnlined design\r\nPockets:\r\nKangaroo pouch pocket\r\nFabric:\r\nThick pure cotton French terry fabric\r\nScreen print on front and back', 4, 2, 3, '2021-03-18 13:40:49', '2021-03-18 13:40:49'),
(22, 'Maxi Beach Dresses Wedding Party', 'Season:Spring ,Summer\r\nFabric:Chiffon+Polyester,slip inside\r\nFeature: Off the shoulder ,Strapless ,Floral print, Front slit ,Elastic Sleeve , lining inside,very soft ,cool in this summer,match with a choker will make you more flattering\r\nOccasion:beach,casual wear,wedding,cocktail , club , party and evening etc.\r\nPackage include :1* Women dress', 6, 2, 1, '2021-03-18 13:48:41', '2021-03-18 13:48:41'),
(23, 'EMBROIDERY MAXI DRESS', '- By Blush Mark\r\n- This garment fits true to size.\r\n- Not Fitted - fuller skirt allows room for hips.\r\n- Great for any cup size.\r\n- Fitted - very fitted at natural waist.\r\n- Fabric has no stretch.\r\n- Size small measures 61\" from shoulder to hem.\r\n- May be worn with an adhesive bra, petals, or no bra.', 6, 2, 3, '2021-03-18 13:50:35', '2021-03-18 13:50:35'),
(24, 'V&A Neha Print V-neck Dress', 'V&A Collaboration Print Short Dress. With tiered panelling, V-neck, full sleeves and covered buttons. Made from luxuriously soft and sustainable 100% TENCEL™ Lyocell by People Tree Fair Trade producer partner Creative Handicrafts.', 6, 2, 1, '2021-03-18 13:51:47', '2021-03-18 13:51:47');

-- --------------------------------------------------------

--
-- Table structure for table `product_comments`
--

CREATE TABLE `product_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `image_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2021-03-18 12:43:37', '2021-03-18 12:43:37'),
(2, 2, 2, '2021-03-18 12:49:16', '2021-03-18 12:49:16'),
(3, 3, 3, '2021-03-18 12:51:36', '2021-03-18 12:51:36'),
(4, 4, 4, '2021-03-18 12:53:34', '2021-03-18 12:53:34'),
(5, 5, 5, '2021-03-18 12:56:38', '2021-03-18 12:56:38'),
(7, 7, 7, '2021-03-18 12:59:33', '2021-03-18 12:59:33'),
(8, 8, 8, '2021-03-18 13:05:43', '2021-03-18 13:05:43'),
(9, 9, 9, '2021-03-18 13:07:30', '2021-03-18 13:07:30'),
(10, 10, 10, '2021-03-18 13:09:34', '2021-03-18 13:09:34'),
(11, 11, 11, '2021-03-18 13:12:42', '2021-03-18 13:12:42'),
(12, 12, 12, '2021-03-18 13:14:27', '2021-03-18 13:14:27'),
(13, 13, 13, '2021-03-18 13:16:25', '2021-03-18 13:16:25'),
(14, 14, 14, '2021-03-18 13:24:52', '2021-03-18 13:24:52'),
(15, 15, 15, '2021-03-18 13:27:05', '2021-03-18 13:27:05'),
(16, 16, 16, '2021-03-18 13:29:01', '2021-03-18 13:29:01'),
(17, 17, 17, '2021-03-18 13:30:53', '2021-03-18 13:30:53'),
(18, 18, 18, '2021-03-18 13:32:17', '2021-03-18 13:32:17'),
(19, 19, 19, '2021-03-18 13:34:32', '2021-03-18 13:34:32'),
(20, 20, 20, '2021-03-18 13:38:19', '2021-03-18 13:38:19'),
(21, 21, 21, '2021-03-18 13:40:49', '2021-03-18 13:40:49'),
(22, 22, 22, '2021-03-18 13:48:41', '2021-03-18 13:48:41'),
(23, 23, 23, '2021-03-18 13:50:35', '2021-03-18 13:50:35'),
(24, 24, 24, '2021-03-18 13:51:47', '2021-03-18 13:51:47'),
(25, 12, 25, '2021-03-18 14:27:59', '2021-03-18 14:27:59'),
(26, 1, 26, '2021-03-18 14:29:52', '2021-03-18 14:29:52'),
(27, 14, 27, '2021-03-18 14:30:40', '2021-03-18 14:30:40'),
(28, 20, 28, '2021-03-18 14:35:11', '2021-03-18 14:35:11');

-- --------------------------------------------------------

--
-- Table structure for table `product_prices`
--

CREATE TABLE `product_prices` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `discount_id` bigint(20) UNSIGNED NOT NULL,
  `price_id` bigint(20) UNSIGNED NOT NULL,
  `new_price` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_prices`
--

INSERT INTO `product_prices` (`id`, `product_id`, `discount_id`, `price_id`, `new_price`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 1, '60.00', '2021-03-18 12:43:37', '2021-03-18 15:10:05'),
(2, 2, 1, 2, '34.00', '2021-03-18 12:49:16', '2021-03-18 12:49:16'),
(3, 3, 3, 3, '40.00', '2021-03-18 12:51:36', '2021-03-18 12:51:36'),
(4, 4, 4, 4, '28.00', '2021-03-18 12:53:34', '2021-03-18 12:53:34'),
(5, 5, 5, 5, '36.00', '2021-03-18 12:56:38', '2021-03-18 12:56:38'),
(7, 7, 6, 5, '30.00', '2021-03-18 12:59:33', '2021-03-18 12:59:33'),
(8, 8, 4, 6, '49.00', '2021-03-18 13:05:43', '2021-03-18 13:05:43'),
(9, 9, 3, 7, '68.00', '2021-03-18 13:07:30', '2021-03-18 13:07:30'),
(10, 10, 7, 8, '48.40', '2021-03-18 13:09:34', '2021-03-18 13:09:34'),
(11, 11, 4, 9, '52.50', '2021-03-18 13:12:42', '2021-03-18 13:12:42'),
(12, 12, 4, 10, '31.50', '2021-03-18 13:14:27', '2021-03-18 15:26:28'),
(13, 13, 4, 11, '20.30', '2021-03-18 13:16:25', '2021-03-18 13:16:25'),
(14, 14, 4, 12, '105.00', '2021-03-18 13:24:52', '2021-03-18 15:47:56'),
(15, 15, 5, 13, '84.00', '2021-03-18 13:27:06', '2021-03-18 13:27:06'),
(16, 16, 6, 14, '100.00', '2021-03-18 13:29:01', '2021-03-18 13:29:01'),
(17, 17, 5, 15, '108.00', '2021-03-18 13:30:53', '2021-03-18 13:30:53'),
(18, 18, 6, 16, '128.00', '2021-03-18 13:32:17', '2021-03-18 13:32:17'),
(19, 19, 6, 17, '150.00', '2021-03-18 13:34:32', '2021-03-18 13:34:32'),
(20, 20, 2, 18, '18.90', '2021-03-18 13:38:19', '2021-03-18 15:19:09'),
(21, 21, 6, 19, '65.00', '2021-03-18 13:40:49', '2021-03-18 13:40:49'),
(22, 22, 3, 20, '241.60', '2021-03-18 13:48:41', '2021-03-18 13:48:41'),
(23, 23, 2, 21, '225.00', '2021-03-18 13:50:35', '2021-03-18 13:50:35'),
(24, 24, 4, 12, '105.00', '2021-03-18 13:51:47', '2021-03-18 13:51:47');

-- --------------------------------------------------------

--
-- Table structure for table `product_sizes`
--

CREATE TABLE `product_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `size_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_sizes`
--

INSERT INTO `product_sizes` (`id`, `product_id`, `size_id`, `quantity`, `created_at`, `updated_at`) VALUES
(7, 2, 1, 0, NULL, '2021-03-18 15:17:10'),
(8, 2, 2, 35, NULL, '2021-03-18 15:39:42'),
(9, 2, 3, 32, NULL, NULL),
(10, 2, 4, 46, NULL, NULL),
(11, 2, 5, 7, NULL, NULL),
(12, 2, 6, 7, NULL, '2021-03-18 15:39:42'),
(13, 3, 1, 12, NULL, NULL),
(14, 3, 2, 32, NULL, NULL),
(15, 3, 3, 54, NULL, NULL),
(16, 3, 4, 49, NULL, NULL),
(17, 3, 5, 85, NULL, NULL),
(18, 3, 6, 15, NULL, NULL),
(19, 4, 1, 10, NULL, '2021-03-18 15:17:10'),
(20, 4, 2, 21, NULL, NULL),
(21, 4, 3, 35, NULL, NULL),
(22, 4, 4, 75, NULL, '2021-03-18 15:17:10'),
(23, 4, 5, 54, NULL, NULL),
(24, 4, 6, 9, NULL, NULL),
(25, 5, 1, 17, NULL, NULL),
(26, 5, 2, 53, NULL, NULL),
(27, 5, 3, 29, NULL, NULL),
(28, 5, 4, 58, NULL, NULL),
(29, 5, 5, 38, NULL, NULL),
(30, 5, 6, 23, NULL, '2021-03-18 15:39:42'),
(37, 7, 1, 1, NULL, NULL),
(38, 7, 2, 3, NULL, NULL),
(39, 7, 3, 2, NULL, NULL),
(40, 7, 4, 17, NULL, '2021-03-18 15:39:42'),
(41, 7, 5, 3, NULL, NULL),
(42, 7, 6, 27, NULL, NULL),
(43, 8, 1, 14, NULL, '2021-03-18 15:17:10'),
(44, 8, 2, 10, NULL, NULL),
(45, 8, 3, 13, NULL, NULL),
(46, 8, 4, 52, NULL, NULL),
(47, 8, 5, 70, NULL, '2021-03-18 15:17:10'),
(48, 8, 6, 45, NULL, NULL),
(49, 9, 1, 15, NULL, NULL),
(50, 9, 2, 10, NULL, NULL),
(51, 9, 3, 13, NULL, NULL),
(52, 9, 4, 23, NULL, NULL),
(53, 9, 5, 8, NULL, NULL),
(54, 9, 6, 53, NULL, NULL),
(55, 10, 1, 15, NULL, NULL),
(56, 10, 2, 10, NULL, NULL),
(57, 10, 3, 13, NULL, NULL),
(58, 10, 4, 23, NULL, NULL),
(59, 10, 5, 8, NULL, NULL),
(60, 10, 6, 53, NULL, NULL),
(61, 11, 1, 1, NULL, NULL),
(62, 11, 2, 10, NULL, NULL),
(63, 11, 3, 13, NULL, NULL),
(64, 11, 4, 2, NULL, NULL),
(65, 11, 5, 8, NULL, NULL),
(66, 11, 6, 5, NULL, NULL),
(73, 13, 1, 1, NULL, NULL),
(74, 13, 2, 0, NULL, NULL),
(75, 13, 3, 13, NULL, NULL),
(76, 13, 4, 19, NULL, NULL),
(77, 13, 5, 28, NULL, NULL),
(78, 13, 6, 4, NULL, NULL),
(85, 15, 1, 2, NULL, NULL),
(86, 15, 2, 14, NULL, NULL),
(87, 15, 3, 7, NULL, NULL),
(88, 15, 4, 65, NULL, NULL),
(89, 15, 5, 5, NULL, NULL),
(90, 15, 6, 0, NULL, NULL),
(91, 16, 1, 20, NULL, '2021-03-18 15:39:42'),
(92, 16, 2, 44, NULL, NULL),
(93, 16, 3, 0, NULL, NULL),
(94, 16, 4, 36, NULL, NULL),
(95, 16, 5, 53, NULL, NULL),
(96, 16, 6, 7, NULL, NULL),
(97, 17, 1, 23, NULL, NULL),
(98, 17, 2, 14, NULL, NULL),
(99, 17, 3, 10, NULL, NULL),
(100, 17, 4, 36, NULL, NULL),
(101, 17, 5, 0, NULL, NULL),
(102, 17, 6, 0, NULL, NULL),
(103, 18, 1, 0, NULL, NULL),
(104, 18, 2, 14, NULL, NULL),
(105, 18, 3, 10, NULL, NULL),
(106, 18, 4, 3, NULL, NULL),
(107, 18, 5, 20, NULL, NULL),
(108, 18, 6, 10, NULL, NULL),
(109, 19, 1, 0, NULL, NULL),
(110, 19, 2, 2, NULL, NULL),
(111, 19, 3, 3, NULL, NULL),
(112, 19, 4, 31, NULL, '2021-03-18 15:28:14'),
(113, 19, 5, 20, NULL, NULL),
(114, 19, 6, 0, NULL, NULL),
(121, 21, 1, 2, NULL, NULL),
(122, 21, 2, 2, NULL, NULL),
(123, 21, 3, 43, NULL, NULL),
(124, 21, 4, 1, NULL, NULL),
(125, 21, 5, 67, NULL, NULL),
(126, 21, 6, 3, NULL, NULL),
(127, 22, 1, 0, NULL, NULL),
(128, 22, 2, 0, NULL, NULL),
(129, 22, 3, 25, NULL, NULL),
(130, 22, 4, 31, NULL, NULL),
(131, 22, 5, 5, NULL, NULL),
(132, 22, 6, 7, NULL, NULL),
(133, 23, 1, 0, NULL, NULL),
(134, 23, 2, 0, NULL, NULL),
(135, 23, 3, 5, NULL, NULL),
(136, 23, 4, 2, NULL, '2021-03-18 15:17:10'),
(137, 23, 5, 5, NULL, NULL),
(138, 23, 6, 0, NULL, NULL),
(139, 24, 1, 0, NULL, NULL),
(140, 24, 2, 0, NULL, NULL),
(141, 24, 3, 15, NULL, NULL),
(142, 24, 4, 23, NULL, NULL),
(143, 24, 5, 15, NULL, NULL),
(144, 24, 6, 2, NULL, NULL),
(181, 1, 0, 25, '2021-03-18 15:10:05', '2021-03-18 15:10:05'),
(182, 1, 1, 63, '2021-03-18 15:10:05', '2021-03-18 15:17:10'),
(183, 1, 2, 54, '2021-03-18 15:10:05', '2021-03-18 15:10:05'),
(184, 1, 3, 78, '2021-03-18 15:10:05', '2021-03-18 15:10:05'),
(185, 1, 4, 93, '2021-03-18 15:10:05', '2021-03-18 15:17:10'),
(186, 1, 5, 78, '2021-03-18 15:10:05', '2021-03-18 15:10:05'),
(187, 20, 0, 1, '2021-03-18 15:19:09', '2021-03-18 15:19:09'),
(188, 20, 1, 1, '2021-03-18 15:19:09', '2021-03-18 15:28:14'),
(189, 20, 2, 3, '2021-03-18 15:19:09', '2021-03-18 15:19:09'),
(190, 20, 3, 3, '2021-03-18 15:19:09', '2021-03-18 15:28:14'),
(191, 20, 4, 8, '2021-03-18 15:19:09', '2021-03-18 15:19:09'),
(192, 20, 5, 1, '2021-03-18 15:19:09', '2021-03-18 15:19:09'),
(193, 12, 0, 1, '2021-03-18 15:26:28', '2021-03-18 15:26:28'),
(194, 12, 1, 10, '2021-03-18 15:26:28', '2021-03-18 15:26:28'),
(195, 12, 2, 13, '2021-03-18 15:26:28', '2021-03-18 15:26:28'),
(196, 12, 3, 22, '2021-03-18 15:26:28', '2021-03-18 15:26:28'),
(197, 12, 4, 6, '2021-03-18 15:26:28', '2021-03-18 15:28:14'),
(198, 12, 5, 49, '2021-03-18 15:26:28', '2021-03-18 15:39:42'),
(199, 14, 0, 11, '2021-03-18 15:47:56', '2021-03-18 15:47:56'),
(200, 14, 1, 45, '2021-03-18 15:47:56', '2021-03-18 15:47:56'),
(201, 14, 2, 78, '2021-03-18 15:47:56', '2021-03-18 15:47:56'),
(202, 14, 3, 65, '2021-03-18 15:47:56', '2021-03-18 15:47:56'),
(203, 14, 4, 42, '2021-03-18 15:47:56', '2021-03-18 15:47:56'),
(204, 14, 5, 7, '2021-03-18 15:47:56', '2021-03-18 15:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', NULL, NULL),
(2, ' user', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `size`, `created_at`, `updated_at`) VALUES
(1, 's', NULL, NULL),
(2, 'm', NULL, NULL),
(3, 'l', NULL, NULL),
(4, 'xl', NULL, NULL),
(5, 'xxl', NULL, NULL),
(6, '3xl', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'men', NULL, NULL),
(2, 'women', NULL, NULL),
(3, 'unisex', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_img` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `lastname`, `phone`, `email`, `password`, `address`, `path_img`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'Aleksa', 'Stosic', '064-222-4444', 'aki.sto99@gmail.com', 'c86a40ef83dfa0802be74d48e7f0c6c7', 'Kursulina 41,', 'qDbRlvtiKSx6HQtgEGCk0KrmQIOZdArrGTMyohtx.jpg', 2, '2021-03-18 12:33:15', '2021-03-18 21:41:34'),
(2, 'Luka', 'Lukic', '0642255826', 'luka123@ict.edu.rs', '87f7e47336de54567c55dbf9b57f8b82', 'Vojvode Stepe, 17b', NULL, 2, '2021-03-18 14:45:31', '2021-03-18 14:45:31'),
(3, 'Cika', 'Admin', '064-555-6666', 'CikaAdmin@gmail.com', '6c42c012cddaf3346d62cc1365c2c4c8', 'Kursulina 41,', NULL, 1, '2021-03-18 15:34:34', '2021-03-18 15:34:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_product_comments`
--

CREATE TABLE `user_product_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_comment_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_users`
--
ALTER TABLE `activity_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_menus`
--
ALTER TABLE `admin_menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_menus_name_unique` (`name`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `brands_name_unique` (`name`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_name_unique` (`name`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `popularity_products`
--
ALTER TABLE `popularity_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_name_unique` (`name`);

--
-- Indexes for table `product_comments`
--
ALTER TABLE `product_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_prices`
--
ALTER TABLE `product_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sizes`
--
ALTER TABLE `product_sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `types_name_unique` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_product_comments`
--
ALTER TABLE `user_product_comments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `activity_users`
--
ALTER TABLE `activity_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `admin_menus`
--
ALTER TABLE `admin_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1665;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `popularity_products`
--
ALTER TABLE `popularity_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `prices`
--
ALTER TABLE `prices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_comments`
--
ALTER TABLE `product_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `product_prices`
--
ALTER TABLE `product_prices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_sizes`
--
ALTER TABLE `product_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_product_comments`
--
ALTER TABLE `user_product_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
